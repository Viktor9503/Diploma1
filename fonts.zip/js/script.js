    "use strict"

    // Всплывающее окно меню

    document.querySelector('#burger').addEventListener('click', function() {

        document.querySelector('#popup__nav').classList.toggle('is-active')

    });
    document.querySelector('.popup__nav').addEventListener('click', function(ev) {
        if (ev.target == this) {
            document.querySelector('#popup__nav').classList.remove('is-active')
        };
    });





    // Swiper

    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 10,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,

        },
        spaceBetween: 50,
        slidesPerView: 1,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },



        breakpoints: {
            576: {
                slidesPerView: 1,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 40,
            },
            992: {
                slidesPerView: 3,
                spaceBetween: 50,
            },
        },
    });





    let btns2 = document.querySelectorAll('.btn2');
    let inputblock = document.querySelector('.block-input');
    let inputs = document.querySelectorAll('.dropdown__input');
    let btnHeaders = document.querySelectorAll('.btn-header');
    let errors = document.querySelectorAll('.error');

    for (let btn2 of btns2) {


        let insertInput = function() {
            inputblock.insertAdjacentHTML('beforeend', '<input id="mail" class="dropdown__input input-mail" type="email" name="email" placeholder="E-mail " data-validate="mail">');
            inputblock.insertAdjacentHTML('beforeend', '<div class="error error-mail"></div>');
        };

        btn2.addEventListener('click', function() {
            let inputMail = document.getElementById('mail');
            let errorMail = document.querySelector('.error-mail');
            if (inputMail) {
                for (let error of errors) {
                    error.textContent = "";
                };
                form.reset();

            } else {
                insertInput();
                for (let error of errors) {
                    error.textContent = "";
                }
                form.reset();

            };

            if (errorMail) {
                errorMail.textContent = "";

            };
            for (let error of errors) {
                error.textContent = "";
            };


        });

    };

    for (let btnHeader of btnHeaders) {

        btnHeader.addEventListener('click', function() {

            let inputMail = document.getElementById('mail');
            let errorMail = document.querySelector('.error-mail');

            if (inputMail) {

                inputMail.remove();
                form.reset();

            } else {
                for (let error of errors) {
                    error.textContent = "";
                }
                form.reset();
            };
            if (errorMail) {
                errorMail.remove();

            };
            for (let error of errors) {
                error.textContent = "";
            }
        });

    };



    // Inputmask

    let selector = document.querySelectorAll("input[type='tel']");
    let im = new Inputmask("+7(999)-999-99-99");
    im.mask(selector);



    // just-validate

    const form = document.querySelector('form');
    const regExpName = /^[а-яА-Я а-яА-Я-]{3,26}$/;
    const regExpPhone = /^(\s*)?(\+)?([- _():=+]?\d[- _():=+]?){11,14}(\s*)?$/;
    const regExpEmail = /^[A-Z0-9._%+-]+@[A-Z0-9-]+.+.[A-Z]{2,4}$/i;
    let isValidate = false;

    const submit = () => {
        alert('Данные отправлены');
    };
    const validateElems = (elem) => {

        if (elem.name === 'text') {
            if (elem.value.length < 3) {
                elem.nextElementSibling.textContent = "Имя не менее 3-х букв!";
            } else {
                elem.nextElementSibling.textContent = "";

                if (!regExpName.test(elem.value) && elem.value != "") {
                    elem.nextElementSibling.textContent = "Введите правильно имя!";
                    isValidate = false;
                } else {
                    elem.nextElementSibling.textContent = "";
                    isValidate = true;
                };
            };
        };
        if (elem.name === 'phone') {
            if (!regExpPhone.test(elem.value)) {
                elem.nextElementSibling.textContent = "Введите правильно номер телефона!";
                isValidate = false;
            } else {
                elem.nextElementSibling.textContent = "";
                isValidate = true;
            };
        };
        if (elem.name === 'email') {
            console.log(elem.name === 'email')
            if (!regExpEmail.test(elem.value)) {
                elem.nextElementSibling.textContent = "Введите правильно e-mail!";
                isValidate = false;
            } else {
                elem.nextElementSibling.textContent = "";
                isValidate = true;
            };

        };


    };
    // console.log(isValidate);

    for (let elem of form.elements) {
        if (elem.tagName != "BUTTON") {
            elem.addEventListener('blur', () => {
                validateElems(elem);

            });
        };
    };


    form.addEventListener("submit", (even) => {
        even.preventDefault();

        for (let elem of form.elements) {
            if (elem.tagName != "BUTTON") {
                if (elem.value === "") {
                    elem.nextElementSibling.textContent = "Поле не заполнено!";
                    isValidate = false;
                } else {
                    elem.nextElementSibling.textContent = "";

                };
            };

        };

        if (isValidate == true) {
            submit();
            form.reset();

        };
    });